create
	procedure [cdc].[sp_insdel_910626287]
	(	@__$start_lsn binary(10),
		@__$seqval binary(10),
		@__$operation int,
		@__$update_mask varbinary(128) , @c6 nvarchar(450), @c7 nvarchar(200), @c8 nvarchar(50), @c9 nvarchar(500), @c10 bit, @c11 nvarchar(450), @c12 datetime2, @c13 datetime2, @c14 nvarchar(450), @c15 nvarchar(450), @c16 bit, @c17 int, @c18 nvarchar(max), @c19 nvarchar(max), @c20 bit, @c21 datetime2, @c22 nvarchar(450), @c23 datetime2, @c24 nvarchar(450), @c25 datetime2,
		@__$command_id int = null
	)
	as
	begin
		insert into [cdc].[dbo_Category_CT] 
		(
			__$start_lsn
			,__$end_lsn
			,__$seqval
			,__$operation
			,__$update_mask , [Id], [Name], [Code], [Description], [IsActive], [ShopId], [ClientCreatedDate], [ClientModifiedDate], [ClientCreatedBy], [ClientModifiedBy], [IsPublic], [Version], [EntityState], [LastModifiedUtc], [IsDeleted], [DeletedAt], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]
			,__$command_id
		)
		values
		(
			@__$start_lsn
			,NULL
			,@__$seqval
			,@__$operation
			,@__$update_mask , @c6, @c7, @c8, @c9, @c10, @c11, @c12, @c13, @c14, @c15, @c16, @c17, @c18, @c19, @c20, @c21, @c22, @c23, @c24, @c25
			,@__$command_id
		)
		return 0
	end
go

