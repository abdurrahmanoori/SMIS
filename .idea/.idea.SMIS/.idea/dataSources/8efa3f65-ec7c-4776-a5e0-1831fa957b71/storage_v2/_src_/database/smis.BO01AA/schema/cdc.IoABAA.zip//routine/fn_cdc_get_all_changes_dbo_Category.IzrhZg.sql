
	create function [cdc].[fn_cdc_get_all_changes_dbo_Category]
	(	@from_lsn binary(10),
		@to_lsn binary(10),
		@row_filter_option nvarchar(30)
	)
	returns table
	return
	
	select NULL as __$start_lsn,
		NULL as __$seqval,
		NULL as __$operation,
		NULL as __$update_mask, NULL as [Id], NULL as [Name], NULL as [Code], NULL as [Description], NULL as [IsActive], NULL as [ShopId], NULL as [ClientCreatedDate], NULL as [ClientModifiedDate], NULL as [ClientCreatedBy], NULL as [ClientModifiedBy], NULL as [IsPublic], NULL as [Version], NULL as [EntityState], NULL as [LastModifiedUtc], NULL as [IsDeleted], NULL as [DeletedAt], NULL as [CreatedBy], NULL as [CreatedDate], NULL as [UpdatedBy], NULL as [UpdatedDate]
	where ( [sys].[fn_cdc_check_parameters]( N'dbo_Category', @from_lsn, @to_lsn, lower(rtrim(ltrim(@row_filter_option))), 0) = 0)

	union all
	
	select t.__$start_lsn as __$start_lsn,
		t.__$seqval as __$seqval,
		t.__$operation as __$operation,
		t.__$update_mask as __$update_mask, t.[Id], t.[Name], t.[Code], t.[Description], t.[IsActive], t.[ShopId], t.[ClientCreatedDate], t.[ClientModifiedDate], t.[ClientCreatedBy], t.[ClientModifiedBy], t.[IsPublic], t.[Version], t.[EntityState], t.[LastModifiedUtc], t.[IsDeleted], t.[DeletedAt], t.[CreatedBy], t.[CreatedDate], t.[UpdatedBy], t.[UpdatedDate]
	from [cdc].[dbo_Category_CT] t with (nolock)    
	where (lower(rtrim(ltrim(@row_filter_option))) = 'all')
	    and ( [sys].[fn_cdc_check_parameters]( N'dbo_Category', @from_lsn, @to_lsn, lower(rtrim(ltrim(@row_filter_option))), 0) = 1)
		and (t.__$operation = 1 or t.__$operation = 2 or t.__$operation = 4)
		and (t.__$start_lsn <= @to_lsn)
		and (t.__$start_lsn >= @from_lsn)
		
	union all	
		
	select t.__$start_lsn as __$start_lsn,
		t.__$seqval as __$seqval,
		t.__$operation as __$operation,
		t.__$update_mask as __$update_mask, t.[Id], t.[Name], t.[Code], t.[Description], t.[IsActive], t.[ShopId], t.[ClientCreatedDate], t.[ClientModifiedDate], t.[ClientCreatedBy], t.[ClientModifiedBy], t.[IsPublic], t.[Version], t.[EntityState], t.[LastModifiedUtc], t.[IsDeleted], t.[DeletedAt], t.[CreatedBy], t.[CreatedDate], t.[UpdatedBy], t.[UpdatedDate]
	from [cdc].[dbo_Category_CT] t with (nolock)     
	where (lower(rtrim(ltrim(@row_filter_option))) = 'all update old')
	    and ( [sys].[fn_cdc_check_parameters]( N'dbo_Category', @from_lsn, @to_lsn, lower(rtrim(ltrim(@row_filter_option))), 0) = 1)
		and (t.__$operation = 1 or t.__$operation = 2 or t.__$operation = 4 or
		     t.__$operation = 3 )
		and (t.__$start_lsn <= @to_lsn)
		and (t.__$start_lsn >= @from_lsn)

    go

    grant select on cdc.fn_cdc_get_all_changes_dbo_Category to cdc_reader
    go

