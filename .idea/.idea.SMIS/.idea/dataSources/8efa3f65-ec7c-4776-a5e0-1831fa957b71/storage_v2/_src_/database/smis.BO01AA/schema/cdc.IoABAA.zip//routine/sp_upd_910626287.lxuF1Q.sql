create
	procedure [cdc].[sp_upd_910626287]
	(	@__$start_lsn binary(10),
		@__$seqval binary(10),
		@__$update_mask varbinary(128) , @c6_old nvarchar(450), @c7_old nvarchar(200), @c8_old nvarchar(50), @c9_old nvarchar(500), @c10_old bit, @c11_old nvarchar(450), @c12_old datetime2, @c13_old datetime2, @c14_old nvarchar(450), @c15_old nvarchar(450), @c16_old bit, @c17_old int, @c18_old nvarchar(max), @c19_old nvarchar(max), @c20_old bit, @c21_old datetime2, @c22_old nvarchar(450), @c23_old datetime2, @c24_old nvarchar(450), @c25_old datetime2, @c6_new nvarchar(450), @c7_new nvarchar(200), @c8_new nvarchar(50), @c9_new nvarchar(500), @c10_new bit, @c11_new nvarchar(450), @c12_new datetime2, @c13_new datetime2, @c14_new nvarchar(450), @c15_new nvarchar(450), @c16_new bit, @c17_new int, @c18_new nvarchar(max), @c19_new nvarchar(max), @c20_new bit, @c21_new datetime2, @c22_new nvarchar(450), @c23_new datetime2, @c24_new nvarchar(450), @c25_new datetime2,
		@__$command_id int = null
	)
	as
	begin
		insert into [cdc].[dbo_Category_CT] 
		(
			__$start_lsn
			,__$end_lsn
			,__$seqval
			,__$operation
			,__$update_mask , [Id], [Name], [Code], [Description], [IsActive], [ShopId], [ClientCreatedDate], [ClientModifiedDate], [ClientCreatedBy], [ClientModifiedBy], [IsPublic], [Version], [EntityState], [LastModifiedUtc], [IsDeleted], [DeletedAt], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]
			,__$command_id
		)
		values
		(
			@__$start_lsn
			,NULL
			,@__$seqval
			,3
			,@__$update_mask , @c6_old, @c7_old, @c8_old, @c9_old, @c10_old, @c11_old, @c12_old, @c13_old, @c14_old, @c15_old, @c16_old, @c17_old, @c18_old, @c19_old, @c20_old, @c21_old, @c22_old, @c23_old, @c24_old, @c25_old
			,@__$command_id
		)
		
		insert into [cdc].[dbo_Category_CT] 
		(
			__$start_lsn
			,__$end_lsn
			,__$seqval
			,__$operation
			,__$update_mask , [Id], [Name], [Code], [Description], [IsActive], [ShopId], [ClientCreatedDate], [ClientModifiedDate], [ClientCreatedBy], [ClientModifiedBy], [IsPublic], [Version], [EntityState], [LastModifiedUtc], [IsDeleted], [DeletedAt], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]
			,__$command_id
		)
		values
		(
			@__$start_lsn
			,NULL
			,@__$seqval
			,4
			,@__$update_mask , @c6_new, @c7_new, @c8_new, @c9_new, @c10_new, @c11_new, @c12_new, @c13_new, @c14_new, @c15_new, @c16_new, @c17_new, @c18_new, @c19_new, @c20_new, @c21_new, @c22_new, @c23_new, @c24_new, @c25_new
			,@__$command_id
		)
		
		return 0
	end
go

