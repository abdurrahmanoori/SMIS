create
	procedure [cdc].[sp_upd_798625888]
	(	@__$start_lsn binary(10),
		@__$seqval binary(10),
		@__$update_mask varbinary(128) , @c6_old int, @c7_old datetime, @c6_new int, @c7_new datetime,
		@__$command_id int = null
	)
	as
	begin
		insert into [cdc].[dbo__powersync_checkpoints_CT] 
		(
			__$start_lsn
			,__$end_lsn
			,__$seqval
			,__$operation
			,__$update_mask , [id], [last_updated]
			,__$command_id
		)
		values
		(
			@__$start_lsn
			,NULL
			,@__$seqval
			,3
			,@__$update_mask , @c6_old, @c7_old
			,@__$command_id
		)
		
		insert into [cdc].[dbo__powersync_checkpoints_CT] 
		(
			__$start_lsn
			,__$end_lsn
			,__$seqval
			,__$operation
			,__$update_mask , [id], [last_updated]
			,__$command_id
		)
		values
		(
			@__$start_lsn
			,NULL
			,@__$seqval
			,4
			,@__$update_mask , @c6_new, @c7_new
			,@__$command_id
		)
		
		return 0
	end
go

