create
	procedure [cdc].[sp_insdel_798625888]
	(	@__$start_lsn binary(10),
		@__$seqval binary(10),
		@__$operation int,
		@__$update_mask varbinary(128) , @c6 int, @c7 datetime,
		@__$command_id int = null
	)
	as
	begin
		insert into [cdc].[dbo__powersync_checkpoints_CT] 
		(
			__$start_lsn
			,__$end_lsn
			,__$seqval
			,__$operation
			,__$update_mask , [id], [last_updated]
			,__$command_id
		)
		values
		(
			@__$start_lsn
			,NULL
			,@__$seqval
			,@__$operation
			,@__$update_mask , @c6, @c7
			,@__$command_id
		)
		return 0
	end
go

