CREATE TRIGGER "ps_view_update_unit_of_measure" INSTEAD OF UPDATE ON "unit_of_measure" FOR EACH ROW BEGIN
SELECT CASE WHEN (OLD.id != NEW.id) THEN RAISE (FAIL, 'Cannot update id') END;
UPDATE "ps_data__unit_of_measure" SET data = json_object('name', powersync_strip_subtype(NEW."name"), 'symbol', powersync_strip_subtype(NEW."symbol"), 'description', powersync_strip_subtype(NEW."description"), 'last_modified_utc', powersync_strip_subtype(NEW."last_modified_utc")) WHERE id = NEW.id;
INSERT INTO powersync_crud(op,id,type,data,old_values,options) VALUES ('PATCH', NEW.id, 'unit_of_measure', json(powersync_diff(json_object('name', powersync_strip_subtype(OLD."name"), 'symbol', powersync_strip_subtype(OLD."symbol"), 'description', powersync_strip_subtype(OLD."description"), 'last_modified_utc', powersync_strip_subtype(OLD."last_modified_utc")), json_object('name', powersync_strip_subtype(NEW."name"), 'symbol', powersync_strip_subtype(NEW."symbol"), 'description', powersync_strip_subtype(NEW."description"), 'last_modified_utc', powersync_strip_subtype(NEW."last_modified_utc")))), json_object('last_modified_utc', powersync_strip_subtype(OLD."last_modified_utc")), 0);
END;

