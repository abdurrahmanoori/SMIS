CREATE TRIGGER "ps_view_delete_product" INSTEAD OF DELETE ON "product" FOR EACH ROW BEGIN
DELETE FROM "ps_data__product" WHERE id = OLD.id;
INSERT INTO powersync_crud(op,id,type,old_values) VALUES ('DELETE', OLD.id, 'product', json_object('last_modified_utc', powersync_strip_subtype(OLD."last_modified_utc")));
END;

