CREATE TRIGGER "ps_view_insert_product_price" INSTEAD OF INSERT ON "product_price" FOR EACH ROW BEGIN
SELECT CASE WHEN (NEW.id IS NULL) THEN RAISE (FAIL, 'id is required') WHEN (typeof(NEW.id) != 'text') THEN RAISE (FAIL, 'id should be text') END;
INSERT INTO "ps_data__product_price" SELECT NEW.id, json_object('product_unit_id', powersync_strip_subtype(NEW."product_unit_id"), 'sell_price', powersync_strip_subtype(NEW."sell_price"), 'effective_date', powersync_strip_subtype(NEW."effective_date"), 'end_date', powersync_strip_subtype(NEW."end_date"), 'last_modified_utc', powersync_strip_subtype(NEW."last_modified_utc"));
INSERT INTO powersync_crud(op,id,type,data) VALUES ('PUT', NEW.id, 'product_price', json(powersync_diff('{}', json_object('product_unit_id', powersync_strip_subtype(NEW."product_unit_id"), 'sell_price', powersync_strip_subtype(NEW."sell_price"), 'effective_date', powersync_strip_subtype(NEW."effective_date"), 'end_date', powersync_strip_subtype(NEW."end_date"), 'last_modified_utc', powersync_strip_subtype(NEW."last_modified_utc")))));
END;

