CREATE TRIGGER "ps_view_delete_category" INSTEAD OF DELETE ON "category" FOR EACH ROW BEGIN
DELETE FROM "ps_data__category" WHERE id = OLD.id;
INSERT INTO powersync_crud(op,id,type,old_values) VALUES ('DELETE', OLD.id, 'category', json_object('last_modified_utc', powersync_strip_subtype(OLD."last_modified_utc")));
END;

