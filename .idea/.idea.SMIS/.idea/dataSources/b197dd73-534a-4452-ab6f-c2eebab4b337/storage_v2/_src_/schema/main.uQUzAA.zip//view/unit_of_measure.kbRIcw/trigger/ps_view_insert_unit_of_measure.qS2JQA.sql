CREATE TRIGGER "ps_view_insert_unit_of_measure" INSTEAD OF INSERT ON "unit_of_measure" FOR EACH ROW BEGIN
SELECT CASE WHEN (NEW.id IS NULL) THEN RAISE (FAIL, 'id is required') WHEN (typeof(NEW.id) != 'text') THEN RAISE (FAIL, 'id should be text') END;
INSERT INTO "ps_data__unit_of_measure" SELECT NEW.id, json_object('name', powersync_strip_subtype(NEW."name"), 'symbol', powersync_strip_subtype(NEW."symbol"), 'description', powersync_strip_subtype(NEW."description"), 'last_modified_utc', powersync_strip_subtype(NEW."last_modified_utc"));
INSERT INTO powersync_crud(op,id,type,data) VALUES ('PUT', NEW.id, 'unit_of_measure', json(powersync_diff('{}', json_object('name', powersync_strip_subtype(NEW."name"), 'symbol', powersync_strip_subtype(NEW."symbol"), 'description', powersync_strip_subtype(NEW."description"), 'last_modified_utc', powersync_strip_subtype(NEW."last_modified_utc")))));
END;

