CREATE TRIGGER "ps_view_delete_product_price" INSTEAD OF DELETE ON "product_price" FOR EACH ROW BEGIN
DELETE FROM "ps_data__product_price" WHERE id = OLD.id;
INSERT INTO powersync_crud(op,id,type,old_values) VALUES ('DELETE', OLD.id, 'product_price', json_object('last_modified_utc', powersync_strip_subtype(OLD."last_modified_utc")));
END;

