CREATE TRIGGER "ps_view_insert_product_unit" INSTEAD OF INSERT ON "product_unit" FOR EACH ROW BEGIN
SELECT CASE WHEN (NEW.id IS NULL) THEN RAISE (FAIL, 'id is required') WHEN (typeof(NEW.id) != 'text') THEN RAISE (FAIL, 'id should be text') END;
INSERT INTO "ps_data__product_unit" SELECT NEW.id, json_object('product_id', powersync_strip_subtype(NEW."product_id"), 'unit_of_measure_id', powersync_strip_subtype(NEW."unit_of_measure_id"), 'base_unit_quantity', powersync_strip_subtype(NEW."base_unit_quantity"), 'last_modified_utc', powersync_strip_subtype(NEW."last_modified_utc"));
INSERT INTO powersync_crud(op,id,type,data) VALUES ('PUT', NEW.id, 'product_unit', json(powersync_diff('{}', json_object('product_id', powersync_strip_subtype(NEW."product_id"), 'unit_of_measure_id', powersync_strip_subtype(NEW."unit_of_measure_id"), 'base_unit_quantity', powersync_strip_subtype(NEW."base_unit_quantity"), 'last_modified_utc', powersync_strip_subtype(NEW."last_modified_utc")))));
END;

