CREATE VIEW "unit_of_measure"("id", "name", "symbol", "description", "last_modified_utc") AS SELECT id, CAST(json_extract(data, '$.name') as TEXT), CAST(json_extract(data, '$.symbol') as TEXT), CAST(json_extract(data, '$.description') as TEXT), CAST(json_extract(data, '$.last_modified_utc') as TEXT) FROM "ps_data__unit_of_measure" -- powersync-auto-generated;

