CREATE TRIGGER "ps_view_insert_category" INSTEAD OF INSERT ON "category" FOR EACH ROW BEGIN
SELECT CASE WHEN (NEW.id IS NULL) THEN RAISE (FAIL, 'id is required') WHEN (typeof(NEW.id) != 'text') THEN RAISE (FAIL, 'id should be text') END;
INSERT INTO "ps_data__category" SELECT NEW.id, json_object('name', powersync_strip_subtype(NEW."name"), 'code', powersync_strip_subtype(NEW."code"), 'description', powersync_strip_subtype(NEW."description"), 'is_active', powersync_strip_subtype(NEW."is_active"), 'shop_id', powersync_strip_subtype(NEW."shop_id"), 'last_modified_utc', powersync_strip_subtype(NEW."last_modified_utc"));
INSERT INTO powersync_crud(op,id,type,data) VALUES ('PUT', NEW.id, 'category', json(powersync_diff('{}', json_object('name', powersync_strip_subtype(NEW."name"), 'code', powersync_strip_subtype(NEW."code"), 'description', powersync_strip_subtype(NEW."description"), 'is_active', powersync_strip_subtype(NEW."is_active"), 'shop_id', powersync_strip_subtype(NEW."shop_id"), 'last_modified_utc', powersync_strip_subtype(NEW."last_modified_utc")))));
END;

