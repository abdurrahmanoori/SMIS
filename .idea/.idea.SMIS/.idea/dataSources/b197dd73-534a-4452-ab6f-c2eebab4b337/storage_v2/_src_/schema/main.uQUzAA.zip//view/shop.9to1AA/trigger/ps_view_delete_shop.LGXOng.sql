CREATE TRIGGER "ps_view_delete_shop" INSTEAD OF DELETE ON "shop" FOR EACH ROW BEGIN
DELETE FROM "ps_data__shop" WHERE id = OLD.id;
INSERT INTO powersync_crud(op,id,type,old_values) VALUES ('DELETE', OLD.id, 'shop', json_object('last_modified_utc', powersync_strip_subtype(OLD."last_modified_utc")));
END;

