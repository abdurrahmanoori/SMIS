CREATE TRIGGER "ps_view_delete_unit_of_measure" INSTEAD OF DELETE ON "unit_of_measure" FOR EACH ROW BEGIN
DELETE FROM "ps_data__unit_of_measure" WHERE id = OLD.id;
INSERT INTO powersync_crud(op,id,type,old_values) VALUES ('DELETE', OLD.id, 'unit_of_measure', json_object('last_modified_utc', powersync_strip_subtype(OLD."last_modified_utc")));
END;

